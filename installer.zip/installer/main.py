# main.py
# O código-fonte para o nosso aplicativo gráfico.

import ctypes
import sdl2
import sdl2.sdlttf

# --- Configurações ---
SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480
FONT_PATH = 'font.ttf'
FONT_SIZE = 28

class NossoApp:
    def __init__(self):
        """Inicializa o SDL, a janela e os recursos."""
        sdl2.SDL_Init(SDL_INIT_VIDEO | sdl2.SDL_INIT_JOYSTICK)
        sdl2.sdlttf.TTF_Init()

        self.janela = sdl2.SDL_CreateWindow(
            b"Meu Primeiro App",
            sdl2.SDL_WINDOWPOS_CENTERED,
            sdl2.SDL_WINDOWPOS_CENTERED,
            SCREEN_WIDTH,
            SCREEN_HEIGHT,
            sdl2.SDL_WINDOW_SHOWN
        )
        self.renderizador = sdl2.SDL_CreateRenderer(self.janela, -1, sdl2.SDL_RENDERER_ACCELERATED)
        self.fonte = sdl2.sdlttf.TTF_OpenFont(FONT_PATH.encode('utf-8'), FONT_SIZE)
        self.cor_do_texto = sdl2.SDL_Color(r=255, g=255, b=255) # Branco

    def run(self):
        """Executa o loop principal do aplicativo."""
        superficie_texto = sdl2.sdlttf.TTF_RenderText_Solid(self.fonte, b"App Criado com Sucesso!", self.cor_do_texto)
        textura_texto = sdl2.SDL_CreateTextureFromSurface(self.renderizador, superficie_texto)

        pos_texto = sdl2.SDL_Rect(
            (SCREEN_WIDTH - superficie_texto.w) // 2,
            (SCREEN_HEIGHT - superficie_texto.h) // 2,
            superficie_texto.w, superficie_texto.h
        )
        sdl2.SDL_FreeSurface(superficie_texto)

        a_correr = True
        evento = sdl2.SDL_Event()
        while a_correr:
            while sdl2.SDL_PollEvent(ctypes.byref(evento)) != 0:
                if evento.type == sdl2.SDL_QUIT: a_correr = False; break
                if evento.type == sdl2.SDL_KEYDOWN:
                    if evento.key.keysym.sym in [sdl2.SDLK_ESCAPE, sdl2.SDLK_BACKSPACE]: a_correr = False; break
                if evento.type == sdl2.SDL_JOYBUTTONDOWN:
                    if evento.jbutton.button == 1: a_correr = False; break # Botão B

            sdl2.SDL_SetRenderDrawColor(self.renderizador, 20, 20, 50, 255) # Fundo azul escuro
            sdl2.SDL_RenderClear(self.renderizador)
            sdl2.SDL_RenderCopy(self.renderizador, textura_texto, None, pos_texto)
            sdl2.SDL_RenderPresent(self.renderizador)
            sdl2.SDL_Delay(16)

        self.cleanup()

    def cleanup(self):
        """Liberta todos os recursos e fecha o SDL."""
        sdl2.sdlttf.TTF_CloseFont(self.fonte)
        sdl2.SDL_DestroyRenderer(self.renderizador)
        sdl2.SDL_DestroyWindow(self.janela)
        sdl2.sdlttf.TTF_Quit()
        sdl2.SDL_Quit()

if __name__ == "__main__":
    app = NossoApp()
    app.run()