#!/bin/sh
APP_DIR=$(dirname "$0")
cd "$APP_DIR"

# Executa o nosso programa compilado!
./MeuApp_Exec

exit 0