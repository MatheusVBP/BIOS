#!/bin/sh

# --- BLOCO DE INICIALIZAÇÃO E DEPURAÇÃO ---
APP_DIR=$(dirname "$0")
cd "$APP_DIR"

# Ativa o modo de depuração para gravar tudo no log.txt
# Apaga o log antigo e cria um novo a cada execução.
exec > "log.txt" 2>&1

echo "--- Log de Depuração do Executável ---"
echo "Data e Hora: $(date)"
echo "Diretório atual: $(pwd)"
echo ""
echo "Conteúdo da pasta:"
ls -la # Lista todos os arquivos com as suas permissões
echo ""

# --- PASSO 1: CORRIGIR PERMISSÕES (O TESTE MAIS IMPORTANTE) ---
echo "A garantir que o nosso programa tem permissão para executar..."
chmod +x ./meuAppexec
echo "Permissão de execução (+x) adicionada a MeuApp_Exec."
echo ""

# --- PASSO 2: PREPARAR O AMBIENTE ---
echo "A preparar o ambiente de bibliotecas..."
# Adiciona os caminhos de bibliotecas mais comuns do sistema
export LD_LIBRARY_PATH=/mnt/SDCARD/System/lib/:/usr/lib/:$LD_LIBRARY_PATH
echo "LD_LIBRARY_PATH definido para: $LD_LIBRARY_PATH"
echo ""

# --- PASSO 3: TENTAR EXECUTAR E GRAVAR O ERRO ---
echo "A tentar executar ./MeuApp_Exec..."
echo "Qualquer erro que ocorra será gravado abaixo desta linha."
echo "----------------------------------------------------"

# Executa o nosso programa E GRAVA QUALQUER SAÍDA OU ERRO no log.txt
# O '2>&1' é crucial para capturar as mensagens de erro.
./meuAppexec

echo "----------------------------------------------------"
echo "Execução do programa terminada."
echo "Se não houver nenhuma mensagem de erro acima, o programa pode ter executado e fechado muito rápido."
echo "Se o sistema congelou, o problema é mais profundo."
echo "--- Fim do Log ---"

# Informa o utilizador na tela que o processo terminou
# (Isto pode não aparecer se o sistema congelar)
/mnt/SDCARD/System/usr/trimui/scripts/infoscreen.sh -m "Depuração concluída! Verifique o log.txt." -k B

exit 0