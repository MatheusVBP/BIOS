# Importa as bibliotecas necessárias
import sdl2
import sdl2.sdlttf
import traceback # Importa a biblioteca para obter detalhes completos do erro
import ctypes

# --- Configuração Inicial ---
LARGURA_ECRA = 640
ALTURA_ECRA = 480
NOME_DA_FONTE = 'font.ttf'
TAMANHO_DA_FONTE = 24

def run():
    print("[Python] Script iniciado.")

    # --- Inicialização ---
    print("[Python] A inicializar SDL2...")
    sdl2.SDL_Init(sdl2.SDL_INIT_VIDEO)
    print("[Python] SDL2 inicializado com sucesso.")

    print("[Python] A inicializar SDL2 TTF (fontes)...")
    sdl2.sdlttf.TTF_Init()
    print("[Python] SDL2 TTF inicializado com sucesso.")

    # --- Criação da Janela e Renderizador ---
    print("[Python] A criar a janela...")
    janela = sdl2.SDL_CreateWindow(b"Ola Mundo Grafico",
                                   sdl2.SDL_WINDOWPOS_UNDEFINED,
                                   sdl2.SDL_WINDOWPOS_UNDEFINED,
                                   LARGURA_ECRA, ALTURA_ECRA,
                                   sdl2.SDL_WINDOW_FULLSCREEN)
    if not janela:
        print(f"[ERRO] Falha ao criar a janela: {sdl2.SDL_GetError()}")
        return
    print("[Python] Janela criada com sucesso.")

    print("[Python] A criar o renderizador...")
    renderizador = sdl2.SDL_CreateRenderer(janela, -1, sdl2.SDL_RENDERER_ACCELERATED)
    if not renderizador:
        print(f"[ERRO] Falha ao criar o renderizador: {sdl2.SDL_GetError()}")
        return
    print("[Python] Renderizador criado com sucesso.")

    # --- Carregamento da Fonte e Texto ---
    print(f"[Python] A carregar a fonte: {NOME_DA_FONTE}...")
    cor_do_texto = sdl2.SDL_Color(r=255, g=255, b=255)
    fonte = sdl2.sdlttf.TTF_OpenFont(NOME_DA_FONTE.encode('utf-8'), TAMANHO_DA_FONTE)
    if not fonte:
        print(f"[ERRO] Falha ao carregar a fonte: {sdl2.sdlttf.TTF_GetError()}")
        return
    print("[Python] Fonte carregada com sucesso.")

    print("[Python] A renderizar o texto...")
    superficie_texto = sdl2.sdlttf.TTF_RenderText_Solid(fonte,
                                                       b"Ola, Mundo Grafico!",
                                                       cor_do_texto)
    textura_texto = sdl2.SDL_CreateTextureFromSurface(renderizador, superficie_texto)
    sdl2.SDL_FreeSurface(superficie_texto)
    print("[Python] Texto renderizado com sucesso.")

    pos_texto = sdl2.SDL_Rect((LARGURA_ECRA - superficie_texto.w) // 2,
                              (ALTURA_ECRA - superficie_texto.h) // 2,
                              superficie_texto.w, superficie_texto.h)

    # --- Loop Principal ---
    print("[Python] A entrar no loop principal...")
    a_correr = True
    evento = sdl2.SDL_Event()
    while a_correr:
        while sdl2.SDL_PollEvent(ctypes.byref(evento)) != 0:
            if evento.type == sdl2.SDL_QUIT:
                a_correr = False
                break
            if evento.type == sdl2.SDL_KEYDOWN:
                if evento.key.keysym.sym == sdl2.SDLK_ESCAPE:
                    a_correr = False
                    break

        sdl2.SDL_SetRenderDrawColor(renderizador, 0, 0, 0, 255)
        sdl2.SDL_RenderClear(renderizador)
        sdl2.SDL_RenderCopy(renderizador, textura_texto, None, pos_texto)
        sdl2.SDL_RenderPresent(renderizador)

    # --- Limpeza Final ---
    print("[Python] A sair do loop principal e a limpar recursos...")
    sdl2.SDL_DestroyTexture(textura_texto)
    sdl2.sdlttf.TTF_CloseFont(fonte)
    sdl2.SDL_DestroyRenderer(renderizador)
    sdl2.SDL_DestroyWindow(janela)
    sdl2.sdlttf.TTF_Quit()
    sdl2.SDL_Quit()
    print("[Python] Recursos limpos. A sair.")

# Bloco principal que executa a função 'run' e captura qualquer erro
if __name__ == "__main__":
    try:
        run()
    except Exception as e:
        # Se ocorrer qualquer erro inesperado, grava-o no log
        print("\n--- ERRO INESPERADO EM PYTHON ---")
        print(traceback.format_exc())
        print("--- FIM DO ERRO ---")