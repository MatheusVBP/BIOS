# Importa as bibliotecas necessárias
import sdl2
import sdl2.sdlttf

# --- Configuração Inicial ---
LARGURA_ECRA = 640
ALTURA_ECRA = 480
NOME_DA_FONTE = 'font.ttf' # O nome do arquivo de fonte que vamos adicionar
TAMANHO_DA_FONTE = 24

def run():
    # Inicializa o SDL2 (vídeo, áudio, etc.)
    sdl2.SDL_Init(sdl2.SDL_INIT_VIDEO)
    
    # Inicializa a biblioteca de fontes do SDL2
    sdl2.sdlttf.TTF_Init()

    # Cria uma janela
    # O último parâmetro faz com que ela ocupe o ecrã todo.
    janela = sdl2.SDL_CreateWindow(b"Ola Mundo Grafico",
                                   sdl2.SDL_WINDOWPOS_UNDEFINED,
                                   sdl2.SDL_WINDOWPOS_UNDEFINED,
                                   LARGURA_ECRA, ALTURA_ECRA,
                                   sdl2.SDL_WINDOW_FULLSCREEN)

    # Cria um "renderizador", o nosso pincel para desenhar na janela
    renderizador = sdl2.SDL_CreateRenderer(janela, -1, sdl2.SDL_RENDERER_ACCELERATED)

    # Carrega a nossa fonte
    cor_do_texto = sdl2.SDL_Color(r=255, g=255, b=255) # Branco
    try:
        fonte = sdl2.sdlttf.TTF_OpenFont(NOME_DA_FONTE.encode('utf-8'), TAMANHO_DA_FONTE)
    except Exception as e:
        print(f"Erro ao carregar a fonte: {e}")
        # Se não encontrar a fonte, sai para não dar erro.
        sdl2.sdlttf.TTF_Quit()
        sdl2.SDL_Quit()
        return

    # Cria a "superfície" do nosso texto (uma imagem do texto)
    superficie_texto = sdl2.sdlttf.TTF_RenderText_Solid(fonte,
                                                       b"Ola, Mundo Grafico!",
                                                       cor_do_texto)
    # Cria a "textura" a partir da superfície (algo que a placa gráfica entende)
    textura_texto = sdl2.SDL_CreateTextureFromSurface(renderizador, superficie_texto)
    sdl2.SDL_FreeSurface(superficie_texto)

    # Posição e tamanho do texto no ecrã
    pos_texto = sdl2.SDL_Rect((LARGURA_ECRA - superficie_texto.w) // 2,
                              (ALTURA_ECRA - superficie_texto.h) // 2,
                              superficie_texto.w, superficie_texto.h)

    # --- Loop Principal do Aplicativo ---
    a_correr = True
    evento = sdl2.SDL_Event()
    while a_correr:
        # Verifica se há eventos (botões pressionados, etc.)
        while sdl2.SDL_PollEvent(ctypes.byref(evento)) != 0:
            # Se o utilizador tentar fechar a janela ou pressionar 'START' (Escape)
            if evento.type == sdl2.SDL_QUIT:
                a_correr = False
                break
            if evento.type == sdl2.SDL_KEYDOWN:
                # O botão START no TrimUI geralmente corresponde à tecla ESCAPE
                if evento.key.keysym.sym == sdl2.SDLK_ESCAPE:
                    a_correr = False
                    break

        # Limpa o ecrã para preto
        sdl2.SDL_SetRenderDrawColor(renderizador, 0, 0, 0, 255)
        sdl2.SDL_RenderClear(renderizador)

        # Copia a nossa textura de texto para o ecrã
        sdl2.SDL_RenderCopy(renderizador, textura_texto, None, pos_texto)

        # Apresenta o que desenhámos no ecrã
        sdl2.SDL_RenderPresent(renderizador)

    # --- Limpeza Final ---
    sdl2.SDL_DestroyTexture(textura_texto)
    sdl2.sdlttf.TTF_CloseFont(fonte)
    sdl2.SDL_DestroyRenderer(renderizador)
    sdl2.SDL_DestroyWindow(janela)
    sdl2.sdlttf.TTF_Quit()
    sdl2.SDL_Quit()

# Executa a nossa função principal
if __name__ == "__main__":
    import ctypes # Necessário para o SDL_PollEvent
    run()