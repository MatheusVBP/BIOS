#!/bin/sh

# Muda para o diretório do aplicativo.
APP_DIR=$(dirname "$0")
cd "$APP_DIR"

# MODO DE DEPURAÇÃO: Redireciona toda a saída (stdout e stderr) para log.txt
exec > "log.txt" 2>&1

echo "--- Log de Depuração do Lançador ---"
echo "Data e Hora: $(date)"
echo "Diretório atual: $(pwd)"
echo ""

echo "Verificando arquivos..."
if [ -f "main.py" ]; then
    echo "  [OK] main.py encontrado."
else
    echo "  [ERRO] main.py NÃO encontrado!"
fi

if [ -f "font.ttf" ]; then
    echo "  [OK] font.ttf encontrado."
else
    echo "  [ERRO] font.ttf NÃO encontrado!"
fi
echo ""

echo "Procurando pelo interpretador Python..."
# Tenta encontrar python3. Se não encontrar, tenta python.
if command -v python3 >/dev/null 2>&1; then
    PYTHON_CMD="python3"
elif command -v python >/dev/null 2>&1; then
    PYTHON_CMD="python"
else
    echo "[ERRO FATAL] Nenhum interpretador Python (python3 ou python) foi encontrado no sistema."
    exit 1
fi

echo "Interpretador Python encontrado: $PYTHON_CMD"
echo "Versão do Python:"
$PYTHON_CMD --version
echo ""

echo "--- Executando o script Python (main.py) ---"

# Configura as variáveis de ambiente essenciais para o SDL2 funcionar.
export PYSDL2_DLL_PATH="/usr/lib/"
export LD_LIBRARY_PATH=/mnt/SDCARD/System/lib/:/usr/lib/:$LD_LIBRARY_PATH
echo "LD_LIBRARY_PATH definido para: $LD_LIBRARY_PATH"
echo ""

# Executa o script Python
$PYTHON_CMD main.py

echo ""
echo "--- Fim da execução do script Python ---"
echo "Se não houver mais logs abaixo, o script Python pode ter travado."

# Garante que o script termina de forma limpa.
exit 0