#!/bin/sh

# Muda para o diretório do aplicativo.
APP_DIR=$(dirname "$0")
cd "$APP_DIR"

# Configura as variáveis de ambiente essenciais para o SDL2 funcionar.
export PYSDL2_DLL_PATH="/usr/lib/"
export LD_LIBRARY_PATH=/mnt/SDCARD/System/lib/:/usr/lib/:$LD_LIBRARY_PATH

# A LINHA MAIS IMPORTANTE:
# Executa o interpretador Python para rodar o nosso script 'main.py'.
# Usamos 'python3', que é o padrão em sistemas modernos.
python3 main.py

# Garante que o script termina de forma limpa.
exit 0