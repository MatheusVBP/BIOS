#!/bin/bash

# --- BLOCO DE INICIALIZAÇÃO ---
# Muda para o diretório do aplicativo.
APP_DIR=$(dirname "$0")
cd "$APP_DIR"

# Define os caminhos para as ferramentas que vamos usar.
INFOSCREEN="/mnt/SDCARD/System/usr/trimui/scripts/infoscreen.sh"
FERRAMENTA_DE_MENU="/mnt/SDCARD/System/bin/whiptail" # O caminho que você encontrou!
# --- FIM DO BLOCO DE INICIALIZAÇÃO ---


# 1. Pedir o nome de utilizador do GitHub
# O '3>&1 1>&2 2>&3' é um truque técnico para o whiptail funcionar corretamente.
USUARIO=$($FERRAMENTA_DE_MENU --inputbox "Digite o utilizador do GitHub:" 10 60 3>&1 1>&2 2>&3)
# Se o utilizador pressionar 'Cancelar', o script termina.
if [ $? -ne 0 ]; then exit; fi

# 2. Pedir o nome do repositório
REPOSITORIO=$($FERRAMENTA_DE_MENU --inputbox "Digite o nome do repositório:" 10 60 3>&1 1>&2 2>&3)
if [ $? -ne 0 ]; then exit; fi

# 3. Pedir a pasta do sistema (GB, GBC, etc.)
PASTA_SISTEMA=$($FERRAMENTA_DE_MENU --inputbox "Salvar em qual pasta de Roms? (ex: GB)" 10 60 "GB" 3>&1 1>&2 2>&3)
if [ $? -ne 0 ]; then exit; fi

$INFOSCREEN -m "A obter a lista de ROMs... Por favor, aguarde." -t 4

# 4. Obter a lista de arquivos e formatá-la para o menu
# Usa 'curl' para aceder à API do GitHub, 'grep' para filtrar e 'sed' para limpar.
LISTA_DE_ARQUIVOS=$(curl -s "https://api.github.com/repos/${USUARIO}/${REPOSITORIO}/contents/" | grep '"name":' | sed 's/.*"name": "\(.*\)",/\1/')

if [ -z "$LISTA_DE_ARQUIVOS" ]; then
    $INFOSCREEN -m "Erro: Não foi possível obter a lista de arquivos. Verifique os nomes e a conexão." -k B
    exit
fi

# Transforma a lista de arquivos numa série de opções para o menu do whiptail
OPCOES_MENU=()
for ARQUIVO in $LISTA_DE_ARQUIVOS; do
    OPCOES_MENU+=("$ARQUIVO" "")
done

# 5. Mostrar o menu para o utilizador escolher a ROM
ROM_ESCOLHIDA=$($FERRAMENTA_DE_MENU --title "Selecione a ROM" --menu "Escolha a ROM para baixar:" 20 78 15 "${OPCOES_MENU[@]}" 3>&1 1>&2 2>&3)
if [ $? -ne 0 ]; then exit; fi

$INFOSCREEN -m "A baixar ${ROM_ESCOLHIDA}..." -t 2

# 6. Baixar a ROM escolhida para o destino correto
URL="https://raw.githubusercontent.com/${USUARIO}/${REPOSITORIO}/main/${ROM_ESCOLHIDA}"
CAMINHO_DESTINO="/mnt/SDCARD/Roms/${PASTA_SISTEMA}/${ROM_ESCOLHIDA}"
wget -O "$CAMINHO_DESTINO" "$URL"

# 7. Verificar se o download foi bem-sucedido e informar o utilizador
if [ $? -eq 0 ]; then
    $INFOSCREEN -m "Download concluído com sucesso!" -k B
else
    $INFOSCREEN -m "ERRO: Falha no download. Verifique a sua conexão." -k B
fi

exit 0
