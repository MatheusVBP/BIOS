#!/bin/bash

# --- BLOCO DE INICIALIZAÇÃO ---
APP_DIR=$(dirname "$0")
cd "$APP_DIR"
# --- FIM DO BLOCO DE INICIALIZAÇÃO ---


# =================================================================
# MODO DE DEPURAÇÃO: Grava toda a saída (normal e de erro) para log.txt
exec > "log.txt" 2>&1
# =================================================================


echo "--- Log de Depuração Avançada ---"
echo "Data e Hora: $(date)"
echo ""

# --- DEFINIÇÃO DE CAMINHOS ---
INFOSCREEN="/mnt/SDCARD/System/usr/trimui/scripts/infoscreen.sh"
FERRAMENTA_DE_MENU="/mnt/SDCARD/System/bin/whiptail"
echo "Caminho do Infoscreen: $INFOSCREEN"
echo "Caminho do Whiptail: $FERRAMENTA_DE_MENU"
echo ""

# --- PASSO 1: Obter nome do utilizador ---
echo "A pedir o nome de utilizador..."
USUARIO=$($FERRAMENTA_DE_MENU --inputbox "Digite o utilizador do GitHub:" 10 60 3>&1 1>&2 2>&3)
CODIGO_SAIDA_USUARIO=$?
echo "Comando para USUARIO executado com código de saída: $CODIGO_SAIDA_USUARIO"
echo "Valor de USUARIO: [${USUARIO}]"
echo ""
if [ $CODIGO_SAIDA_USUARIO -ne 0 ]; then echo "Utilizador cancelou. A sair."; exit; fi

# --- PASSO 2: Obter nome do repositório ---
echo "A pedir o nome do repositório..."
REPOSITORIO=$($FERRAMENTA_DE_MENU --inputbox "Digite o nome do repositório:" 10 60 3>&1 1>&2 2>&3)
CODIGO_SAIDA_REPOSITORIO=$?
echo "Comando para REPOSITORIO executado com código de saída: $CODIGO_SAIDA_REPOSITORIO"
echo "Valor de REPOSITORIO: [${REPOSITORIO}]"
echo ""
if [ $CODIGO_SAIDA_REPOSITORIO -ne 0 ]; then echo "Utilizador cancelou. A sair."; exit; fi

# --- PASSO 3: Obter pasta do sistema ---
echo "A pedir a pasta do sistema..."
PASTA_SISTEMA=$($FERRAMENTA_DE_MENU --inputbox "Salvar em qual pasta de Roms? (ex: GB)" 10 60 "GB" 3>&1 1>&2 2>&3)
CODIGO_SAIDA_PASTA=$?
echo "Comando para PASTA_SISTEMA executado com código de saída: $CODIGO_SAIDA_PASTA"
echo "Valor de PASTA_SISTEMA: [${PASTA_SISTEMA}]"
echo ""
if [ $CODIGO_SAIDA_PASTA -ne 0 ]; then echo "Utilizador cancelou. A sair."; exit; fi

# --- PASSO 4: Obter lista de arquivos ---
URL_API="https://api.github.com/repos/${USUARIO}/${REPOSITORIO}/contents/"
echo "URL da API: ${URL_API}"
echo "A executar curl para obter a lista de arquivos..."
LISTA_DE_ARQUIVOS=$(curl -s "$URL_API" | grep '"name":' | sed 's/.*"name": "\(.*\)",/\1/')
echo "Comando curl/grep/sed executado."
echo "--- Conteúdo da LISTA_DE_ARQUIVOS ---"
echo "${LISTA_DE_ARQUIVOS}"
echo "--- Fim do conteúdo da lista ---"
echo ""

# --- PASSO 5: Construir e mostrar o menu ---
echo "A construir as opções do menu..."
OPCOES_MENU=()
for ARQUIVO in $LISTA_DE_ARQUIVOS; do
    echo "Adicionando opção: $ARQUIVO"
    OPCOES_MENU+=("$ARQUIVO" "")
done
echo "Opções do menu construídas."
echo ""

echo "A mostrar o menu de seleção..."
ROM_ESCOLHIDA=$($FERRAMENTA_DE_MENU --title "Selecione a ROM" --menu "Escolha a ROM para baixar:" 20 78 15 "${OPCOES_MENU[@]}" 3>&1 1>&2 2>&3)
CODIGO_SAIDA_MENU=$?
echo "Comando do menu executado com código de saída: $CODIGO_SAIDA_MENU"
echo "ROM escolhida: [${ROM_ESCOLHIDA}]"
echo ""
if [ $CODIGO_SAIDA_MENU -ne 0 ]; then echo "Utilizador cancelou. A sair."; exit; fi

# --- PASSO 6: Baixar o arquivo ---
URL_DOWNLOAD="https://raw.githubusercontent.com/${USUARIO}/${REPOSITORIO}/main/${ROM_ESCOLHIDA}"
CAMINHO_DESTINO="/mnt/SDCARD/Roms/${PASTA_SISTEMA}/${ROM_ESCOLHIDA}"
echo "URL de Download: ${URL_DOWNLOAD}"
echo "Caminho de Destino: ${CAMINHO_DESTINO}"
echo "A executar wget..."
wget -O "$CAMINHO_DESTINO" "$URL_DOWNLOAD"
CODIGO_SAIDA_WGET=$?
echo "Comando wget executado com código de saída: $CODIGO_SAIDA_WGET"
echo ""

# --- FIM ---
echo "--- Fim do Log ---"

# Informa o utilizador na tela que o processo terminou
$INFOSCREEN -m "Depuração concluída! Verifique o arquivo log.txt na pasta do app." -k B

exit 0