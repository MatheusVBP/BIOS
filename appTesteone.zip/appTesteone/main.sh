#!/bin/sh
whiptail --title "Olá Mundo App" --msgbox "Você criou seu primeiro app para o CrossMix-OS!" 10 50
